<?php


namespace bulder\Models;


class Car
{

    public function setPart($name,$value)
    {

    }
}